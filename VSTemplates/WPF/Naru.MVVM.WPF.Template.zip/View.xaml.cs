﻿namespace $rootnamespace$.$fileinputname$
{
    public partial class $fileinputname$View
    {
        public $fileinputname$View()
        {
            InitializeComponent();
        }
    }
}